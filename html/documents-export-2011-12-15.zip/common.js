function generateSVGElement(name) {
	return document.createElementNS("http://www.w3.org/2000/svg", name);
}
function plus(a,b) {
	return a.map(function(x,i) { return x + b[i];})
}
function minus(a,b) {
	if (b) {
		return a.map(function(x,i) { return x - b[i]})		
	} else {
		return a.map(function(x) { return -x})		
	}
}
function mul(a,b) {
	return a.map(function(x,i) { return x * b[i];})
}
function div(p,a) {
	return p.map(function(x) {return x/a});
}
function scale(p,a) {
	return p.map(function(x) {return x*a});
}
function scalarplus(a,b) {
	return a + b;
}
function normalize(p) {
	return div(p, norm(p));
}
function norm(p) {
	return Math.sqrt(norm2(p));
}
function norm2(p) {
	return dot(p,p);
}
function dot(p1,p2) {
	return mul(p1,p2).reduce(scalarplus);
}

function nxt(i) {
	return (i + 1) % 3;
}
function prv(i) {
	return (3 + i - 1) % 3;
}
function cross(p1,p2) {
	return p1.map(function(x,i) {return  p1[nxt(i)] * p2[prv(i)] - p1[prv(i)] * p2[nxt(i)]});
}
function normalize(p) {
	return div(p, norm(p));
}
function cameraproject(focal, p) {
	return [300 + p[0] * 300 * focal / (p[2] - focal), 300 + p[1] * 300 * focal / (p[2] - focal)];
}
function project(v, a) {
	return scale(a, dot(v,a)/dot(a,a));
}


function projectToPlane(v, a) {
	return minus(v, project(v, a))
}