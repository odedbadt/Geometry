
function createCircle(x, y, r) {
	var circle = generateSVGElement('circle');
	circle.setAttribute('cx', tos(x));
	circle.setAttribute('cy', tos(y));
	circle.setAttribute('r', tos(r));
	return circle;
}
function stylize(element, fill, color, strokeWidth, opacity) {
	element.setAttribute('opacity', opacity);
	element.setAttribute('stroke-width', strokeWidth);
	element.setAttribute('stroke', color);
	element.setAttribute('fill', fill);
	return element;
}
function createPath(points) {
	var path = generateSVGElement('path');
	path.setAttribute('d', 'M' + points.map(function(p){return tos(p[0])+','+tos(p[1])}).join('L'))
	return path;
}

function tos(d) {
	return Math.round(d*100) / 100;
}