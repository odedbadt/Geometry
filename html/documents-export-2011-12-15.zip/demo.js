function dottedpath(v1, v2) {
	var res =[];

	var N = Math.ceil(Math.acos(dot(normalize(v1), normalize(v2))) * 10);
	for (var i = 0; i <= N; ++i) {
		v = normalize(plus(scale(v1, 1-i/N), scale(v2, i/N)));
		res.push(v);
	}
	return res;
}

function closedpath(vs) {
	var res = [];
	res.push(vs[0]);
	for (var i = 0; i < vs.length; ++i) {
		res = res.concat(dottedpath(vs[i], vs[(i+1) % vs.length]))
	}
	return res;
}

function ellipse2d(p1,p2,p3,p4) {
	
}

function ignite() {
	
	var vs = [normalize([Math.random()-0.5, Math.random()-0.5, Math.random()+0.5]),
			  normalize([Math.random()-0.5, Math.random()-0.5, Math.random()+0.5]),
			  normalize([Math.random()-0.5, Math.random()-0.5, Math.random()+0.5])];


	var bases = vs.map(function(x,i) {
		return normalize(projectToPlane(x, cross(vs[(i+1) % 3], vs[(i+2) % 3])))
	})

	var points = closedpath(vs).map(cameraproject.bind(null, [10]))
	document.getElementById('main').appendChild(stylize(createPath(points), 'none', 'black', 1,  1));

	var points = closedpath(bases).map(cameraproject.bind(null, [10]))
	document.getElementById('main').appendChild(stylize(createPath(points), 'none', 'red', 1,  1));

	vs.forEach(function(v,i) {
		var height = dottedpath(vs[i], bases[i]).map(cameraproject.bind(null, [10]));
		document.getElementById('main').appendChild(stylize(createPath(height), 'none', 'blue', 1,  1));
	})
}