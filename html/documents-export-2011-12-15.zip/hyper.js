


function toscreen(p) {
	return [300 + p[0]*200, 300 - p[1]*200];
}
function toscreenLength(p) {
	o = toscreen([0, 0])
	p1 = toscreen([p, 0])

	return Math.abs(p1[0] - o[0]);
}


function s1Middle(a1, a2) {
	return (a1 + s1Dist(a1, a2) / 2) % (2*Math.PI);
}

function s1Dist(a1, a2) {
	return (2*Math.PI + a2 - a1) % (2*Math.PI);

}

function line(a1, a2) {
	return [s1Middle(a1, a2), 1 / Math.cos(s1Dist(a1, a2) / 2)];
}

function drawLine(a, b) {
		var l = line(a, b);

		var c = scale([Math.cos(l[0]), Math.sin(l[0])], l[1]);
		var r = Math.sqrt(l[1] * l[1] - 1);
		var sc = toscreen(c)
		var sr = toscreenLength(r)
		console.log(c, sc, r, sr)

		document.getElementById('main').appendChild(stylize(createCircle(sc[0],sc[1],sr), 'none', 'blue', 0.5,  1));			
}


function ignite() {

	var a = 0;
	var b = 1.17;
	var c = 2;
/*	var v1 = [1, 0];

	var v2 = [Math.cos(a), Math.sin(a)];
	var v3 = [Math.cos(b), Math.sin(b)];*/


	var center = toscreen([0,0])
	var radius = toscreenLength(1)

	document.getElementById('main').appendChild(stylize(createCircle(center[0],center[1],radius), 'none', 'black', 0.5,  1));

//	drawLine(0, Math.PI/2)
	[[a,b],[b,c],[c,a]].forEach(function(x) {
		drawLine(x[0], x[1])
	});


}